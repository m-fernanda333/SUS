package com.suscalculator.run;


/*importando todos os membros estaticos */

import com.suscalculator.gui.Sus;


public class RodarProgramaSus{

		public static void main(String[] args)
		{
			Sus sus = new Sus();
			sus.frame();

		}

	

}
