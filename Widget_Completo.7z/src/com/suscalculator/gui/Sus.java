package com.suscalculator.gui;

import java.awt.dnd.*;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;

public class Sus implements MouseListener, DropTargetListener

{
	boolean selecionado;
	
/*-----------------------CRIA E ESTILIZA A JANELA DO PROGRAMA ----------------------------------//
    /**
     * @author Shayene
     */
	public  void frame() 
	{
		
		ImageIcon image = new ImageIcon("logo.png");//criando imagem de icone 
		ImageIcon imagem = new ImageIcon("csv.png"); //cria  o icone para o frame

		JPanel retangulo = new JPanel();
		retangulo.setBackground(new Color (0xD3D3D3)); 
		retangulo.setBounds(90, 200, 700, 150); //setando o tamanho do retangulo 
												//mudando a  cor de fundo do retangulo


		JLabel label = new JLabel(); //cria a label
		JLabel textoCima = new JLabel();


		JFrame frame = new JFrame(); //cria o frame
		
		frame.setTitle("Escala de Usabilidade do Sistema (SUS)");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //fecha a aplicação
		frame.setResizable(false);//não permite que a janela seja redimensionada pelo usuário
		frame.setSize(900, 600);//define a largura e altura da janela


		frame.getContentPane().setBackground(new Color(0xe9e9e9));//muda a cor de fundo do frame
		frame.setLocationRelativeTo(null);//posicionando o frame no meio da página


		frame.setIconImage(image.getImage()); //muda o icone do frame

		label.setIcon(imagem);
		imagem.setImage(imagem.getImage().getScaledInstance(80, 80, 320));//redimensionando o tamanho da imagem passando como parametro ,largura ,altura e tamanho final


		label.setHorizontalTextPosition(JLabel.CENTER);//posicionando o texto no centro
		label.setVerticalTextPosition(JLabel.BOTTOM);//posicionando o texto embaixos
		label.setHorizontalAlignment(SwingConstants.CENTER);//posicionando o texto no centro absoluto do frame
		label.setVerticalAlignment(SwingConstants.CENTER); //posicionando o texto no centro absoluto do frame
		label.setFont(new Font("Roboto",Font.BOLD,22)); //mudando a fonte para negrito
		label.setCursor(new Cursor(Cursor.HAND_CURSOR));//colocando o cursor em forma de mãozinha na label
		
		
		frame.setVisible(true);//ativa a visibilidade 
		retangulo.add(label); //adicionaindo a label ao retangulo
		frame.add(retangulo);
		frame.add(label);
		frame.add(textoCima);
		
		

		// Widget: Esse JLabel funciona como um botão; Ao ser clicado, o usuário poderá escolher um arquivo com a extensão .csv; 
		
		// Container: Este container guarda o botão que realiza a função de busca de arquivo, bem como o ícone 
		//  		  que indica os limites deste botão;
		
		retangulo.setComponentZOrder(label, 0); //priorizando o label ao inves do jpanel
		label.setText("Selecione seu arquivo .csv");//injetando texto no frame
		
		//Evento: Se esta JLabel receber um clique com o botão esquerdo do mouse,irá ativar o evento relacionado.
		
		label.addMouseListener(this); /*só vai permitir  que o evento aconteça caso clique em um local especifico)*/
		
		textoCima.setText("Escala de usabilidade do sistema");
		textoCima.setVerticalTextPosition(JLabel.TOP);
		textoCima.setHorizontalAlignment(SwingConstants.CENTER);//posicionando o texto no centro absoluto do frame
		textoCima.setVerticalAlignment(SwingConstants.TOP); //posicionando o texto no centro absoluto do frame
		textoCima.setFont(new Font("Roboto",Font.BOLD,45)); //mudando a fonte para negrito
		textoCima.setBackground(new Color(123, 50, 250));
		textoCima.setOpaque(true);
		Border b2 = BorderFactory.createLineBorder(Color.YELLOW,3);
		textoCima.setBorder(b2);
		//Evento: Arrastar um arquivo do File Explorer para qualquer parte do programa;
		
		//Tratamento de evento: O programa analisa se o arquivo fornecido possui a extensão .csv;
		//Caso possua, executará as funções do programa normalmente, e caso não, apresentará uma mensagem de erro.
		new  FileDrop( frame, new FileDrop.Listener()
		  {   public void  filesDropped( java.io.File[] files )
		      {   
				
			  int respostaSelecionador = 0;
			  
			 for(File f : files) {
				 if(f.toString().contains(".csv")==true) {
					 selecionado =true;
					 File selectedFile = new File(f.getAbsolutePath());
					 mostraResultadoFrame(label, selectedFile);
					 respostaSelecionador = 1;
					 break;
				 };
			 };
			 

				if (respostaSelecionador != 1)
				{
					respostaSelecionador = 0;
		            selecionado = false;
					//aqui podemos colocar um menu popup ou um joption pane de warning*/
					JOptionPane.showMessageDialog(null, "Arquivo selecionado não possui extensão .csv!!!", "Erro", JOptionPane.ERROR_MESSAGE);

				}
				
				
				
		      }   // end filesDropped
		  }); // end FileDrop.Listener
		
		 new  FileDrop( label, new FileDrop.Listener()
		  {   public void  filesDropped( java.io.File[] files )
		      {   
				
			  int respostaSelecionador = 0;
			  
			 for(File f : files) {
				 if(f.toString().contains(".csv")==true) {
					 selecionado =true;
					 File selectedFile = new File(f.getAbsolutePath());
					 mostraResultadoFrame(label, selectedFile);
					 respostaSelecionador = 1;
					 break;
				 };
			 };
			 

				if (respostaSelecionador != 1)
				{
					respostaSelecionador = 0;
		            selecionado = false;
					JOptionPane.showMessageDialog(null, "Arquivo selecionado não possui extensão .csv!!!", "Erro", JOptionPane.ERROR_MESSAGE);

				}
		      }   // end filesDropped
		  }); // end FileDrop.Listener
		
	}

//-----------------------ATIVA O EVENTO QUANDO O MOUSE FOR CLICADO------------------------//
	/**@author Shayene
	 * 
	 */

	/*método que só permite a abertura do filechooser quando clicar na label)*/
	
	//Tratamento de evento: Após perceber o clique do botão esquerdo do mouse na área delimitada, será tratado o evento do clique
	//com a invocação do FileChooser;
	@Override
	public void mouseClicked(MouseEvent e)
	{
		/*labels*/
		JLabel label = new JLabel(); //cria a label

		/*criando o selecionador de arquivos */
		JFileChooser  selecionador = new JFileChooser();

		FileNameExtensionFilter filtro = new FileNameExtensionFilter("Selecione Apenas arquivos .csv", "csv");/*CRIANDO FILTRO .csv*/
		selecionador.setAcceptAllFileFilterUsed(false);	/*não aceitar outros arquivos */
		selecionador.addChoosableFileFilter(filtro);	/*adicionando o filtro*/

		selecionador.setFileSelectionMode(JFileChooser.FILES_ONLY);/*seleciona apenas arquivos */ 
		int respostaSelecionador = selecionador.showOpenDialog(label);

		if (respostaSelecionador == JFileChooser.APPROVE_OPTION)
		{
			File selectedFile = selecionador.getSelectedFile();
			System.out.println(selectedFile.getAbsolutePath());//pegando o caminho absoluto*/
            selecionado =true;
            mostraResultadoFrame(label, selectedFile);

		}else
		{
            selecionado = false;
		}
	}
	
	
	//----------------MOSTRA RESULTADO ----------------------//
	
	/**@author Shayene
	 * @param label
	 * @param arquivo
	 */
	
	//Callback: Essa função é chamada após a realização dos cálculos utilizando os valores do arquivo .csv;
	
	
	public void mostraResultadoFrame(JLabel label,File arquivo)
	{		
	
	
		double calculoFinal;
		
		calculoFinal = calcula(selecionado, arquivo);
		
		if(calculoFinal==-1) {
			selecionado = false;
			JOptionPane.showMessageDialog(null, "Arquivo Vazio!", "Erro", JOptionPane.ERROR_MESSAGE);
			return;
		};
		if(calculoFinal==-2) {
			selecionado = false;
			JOptionPane.showMessageDialog(null,"Arquivo possui dados inválidos!!!", "Erro", JOptionPane.ERROR_MESSAGE);
			return;
		};
		
		JFrame resultado = new JFrame();


		JLabel  cor = new JLabel();
		cor.setSize(885, 560);
		Color c = new Color(200, 200, 200);
		cor.setBackground(c);
		Border a = BorderFactory.createLineBorder(Color.GREEN,3);
		Border b = BorderFactory.createLineBorder(Color.YELLOW,3);
		Border d = BorderFactory.createLineBorder(Color.RED,3);
		
		//Ajusta a cor da borda de acordo com o resultado obtido
		if (calculoFinal <50)
			cor.setBorder(d);
 	     
 		if ((calculoFinal >= 50)  && (calculoFinal <= 70)) 
 			cor.setBorder(b);
 
 		if (calculoFinal >= 70)
 
 			cor.setBorder(a);
 		
		
		cor.setOpaque(true);
		
		JLabel  telaFinal = new JLabel();
		JLabel  stringFinal = new JLabel();
		
		ImageIcon image = new ImageIcon("regua.png");//criando imagem de icone 
		Image imagem = image.getImage();
		Image newimagem = imagem.getScaledInstance(900, 400,  java.awt.Image.SCALE_SMOOTH);
		image = new ImageIcon(newimagem);
		telaFinal.setIcon(image);

		
		ImageIcon image2 = new ImageIcon("seta.png");//criando imagem de icone 
		Image imagem2 = image2.getImage(); // transform it 
		Image newimagem2 = imagem2.getScaledInstance(390/4, 540/4,  java.awt.Image.SCALE_SMOOTH);
		image2 = new ImageIcon(newimagem2);
		
		
		
		resultado.setTitle("Escala de Usabilidade do Sistema (SUS)-RESULTADO");
		resultado.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); //fecha a aplicação
		resultado.setResizable(false);//não permite que a janela seja redimensionada pelo usuário
		resultado.setSize(900, 600);//define a largura e altura da janela
		resultado.getContentPane().setBackground(new Color(0xe9e9e9));//muda a cor de fundo do frame
		resultado.setLocationRelativeTo(null);//posicionando o frame no meio da página
		resultado.setVisible(true);//ativa a visibilidade   
		resultado.setLayout(null);
		
		 resultado.add(telaFinal);
		 resultado.add(stringFinal);
		 
		 telaFinal.setBounds(-10, 0, 1000, 800);
		 String valorFinal = String.format("%1.2f", calculoFinal);
			
		
		 System.out.println(calculoFinal);
		String status = status(calculoFinal,stringFinal);
		String formatoString =formatadaString(valorFinal,status);
		
		
		JLabel seta = new JLabel();
		
		resultado.add(seta);
		seta.setSize(390/4,540/4);
		seta.setIcon(image2);
		
		int x = calculaX(calculoFinal);
		seta.setBounds(x, 220, 400, 400);//Calcula a posição que a seta assumirá na representação gráfica.
		
		stringFinal.setText(formatoString);
		stringFinal.setVerticalTextPosition(JLabel.CENTER);
		stringFinal.setHorizontalTextPosition(JLabel.CENTER);
		stringFinal.setOpaque(true);
		stringFinal.setBounds(-10, 50, 900, 200);
		stringFinal.setFont(new Font("Roboto",Font.BOLD,75)); //mudando a fonte para negrito
		stringFinal.setHorizontalAlignment(SwingConstants.CENTER);//posicionando o texto no centro absoluto do frame
		stringFinal.setVerticalAlignment(SwingConstants.CENTER); //posicionando o texto no centro absoluto do frame
		telaFinal.setFont(new Font("Roboto",Font.BOLD,110)); //mudando a fonte para negrito
	
		resultado.add(cor);
		
	}
	
	/*----------------------------CALCULA A COORDENADA X QUE A SETA DEVERÁ ASSUMIR---------------------------------------*/
	
	public int calculaX(double result) {
		
		final int passo = 72;
		
		final int pos0 = 23,
				  pos10 = pos0 + passo,
				  pos20 = pos10 + passo,
				  pos30 = pos20 + passo,
				  pos40 = pos30 + passo,
				  pos50 = pos40 + passo,
				  pos60 = pos50 + passo,
				  pos70 = pos60 + passo,
				  pos80 = pos70 + passo,
				  pos90 = pos80 + passo,
				  pos100 = pos90 + passo;
	
		if(result==0)
			return pos0;
		if(result==10)
			return pos10;
		if(result==20)
			return pos20;
		
		if(result==30)
			return pos30;
		if(result==40)
			return pos40;
		if(result==50)
			return pos50;
		
		if(result==60)
			return pos60;
		if(result==70)
			return pos70;
		if(result==80)
			return pos80;
		
		if(result==90)
			return pos90;
		
		if(result==100)
			return pos100;
		
		if(result < 5)
			return pos0 + passo/3;
		if(result == 5)
			return pos0 + passo/2;
		if(result > 5 && result < 10)
			return pos0 + passo-passo/4;
	
		if(result < 15)
			return pos10 + passo/3;
		if(result == 15)
			return pos10 + passo/2;
		if(result > 15 && result < 20)
			return pos10 + passo-passo/4;
		
		if(result < 25)
			return pos20 + passo/3;
		if(result == 25)
			return pos20 + passo/2;
		if(result > 25 && result < 30)
			return pos20 + passo-passo/4; 
		

		if(result < 35)
			return pos30 + passo/3;
		if(result == 35)
			return pos30 + passo/2;
		if(result > 35 && result < 40)
			return pos30 + passo-passo/4;
		
		if(result < 45)
			return pos40 + passo/3;
		if(result == 45)
			return pos40 + passo/2;
		if(result > 45 && result < 50)
			return pos40 + passo-passo/4; 
	
		
		
		if(result < 55)
			return pos50 + passo/3;
		if(result == 55)
			return pos50 + passo/2;
		if(result > 55 && result < 60)
			return pos50 + passo-passo/4;
		
		if(result < 65)
			return pos60 + passo/3;
		if(result == 65)
			return pos60 + passo/2;
		if(result > 65 && result < 70)
			return pos60 + passo-passo/4; 
		

		if(result < 75)
			return pos70 + passo/3;
		if(result == 75)
			return pos30 + passo/2;
		if(result > 75 && result < 80)
			return pos70 + passo-passo/4;
		
		if(result < 85)
			return pos80 + passo/3;
		if(result == 85)
			return pos80 + passo/2;
		if(result > 85 && result < 90)
			return pos80 + passo-passo/4; 
		
		if(result < 95)
			return pos90 + passo/3;
		if(result == 95)
			return pos90 + passo/2;
		if(result > 95 && result < 100)
			return pos90 + passo-passo/4; 
		
		return 0;
	};
	
	
//-----------------CALCULA O RESULTADO DO SUS-------------//
	
	
	/**@author Ruan Almeida
	 * 
	 * @param selecionado 
	 * @param arquivo
	 * @return
	 */
	//Callback: Essa função é chamada após a realização dos cálculos utilizando os valores do arquivo .csv;
	@SuppressWarnings("resource")
	private double calcula(boolean selecionado,File arquivo)
	{
		double valorSus = 0;
		int numIteracoes = 0;

		if(selecionado==true) {
			
			try {
				Scanner inputStream = new Scanner(arquivo);
				
				if(inputStream.hasNext()==false)
					return -1;
				
			
				while(inputStream.hasNext()) {
					String data = inputStream.next();
				
					int result = 0;
					
					if(data.contains(":")==true ) {
						String[] vetor = data.split(",", 0);
						for(int i = 1;i<11;i++) {
							int num = Integer.parseInt(vetor[i]);
							
							if(num<0 || num > 5)
								return -2;
							
							if(i%2 == 0) 
								result += (5-num);
							
							else 
								result += (num - 1);
							
						};
						
						valorSus += result*2.5;
						numIteracoes++;
					}else{
						if((data.contains("1,")==true)||
								(data.contains("2,")==true||
								(data.contains("3,")==true)||
								(data.contains("4,")==true)||
								(data.contains("5,")==true))) {
							String[] vetor = data.split(",", 0);
							for(int i = 1;i<10;i++) {
								int num = Integer.parseInt(vetor[i]);
								
								if(num<0 || num > 5)
									return -2;
								
								if(i%2 == 0) 
									result += (5-num);
								
								else 
									result += (num - 1);
								
							};
							
							valorSus += result*2.5;
							numIteracoes++;
							
						};
						
					};
				};
					
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
			
		}
		
		return valorSus/numIteracoes;


	}
	

	
//---------------------- INFORMA O STATUS DO RESULTADO------------------------//
	
       public static String status(double x,JLabel label)
       {
    	
   		 String status = null ;
   		
    	   if (x <50)
    	   {
    		   status = "- Inaceitável";
    		   label.setBackground(Color.red);
    	   }
    	     
    		if ((x >= 50)  && (x <= 70)) 
    			
    		{
    		    status = "- Marginal";
    		    label.setBackground(Color.yellow);
    		    
    		}
    		if (x >= 70)
    		{
    			status = "- Aceitável";
    			label.setBackground(Color.green);
    		}
    		
    		
    		return status;
    			
    		   
    	   }
//-----------------------------FORMATA STRING---------------------------------//      
       public static String formatadaString(String um, String dois)
       {
    	    String formatoString=String.format("%s  %s",um,dois);
    	   
    	   
    	   return formatoString;
       } 

       /*Eventos necessários para que a classe abstrata que detecta eventos de clique de mouse possa ser
        * implementada sem erros*/
	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	
/*Eventos necessários para que a classe abstrata que detecta eventos de Drag n' Drop possa ser
 * implementada sem erros*/
	@Override
	public void dragEnter(DropTargetDragEvent dtde) {
	}

	@Override
	public void dragOver(DropTargetDragEvent dtde) {
	}

	@Override
	public void dropActionChanged(DropTargetDragEvent dtde) {
	}

	@Override
	public void dragExit(DropTargetEvent dte) {
	}

	@Override
	public void drop(DropTargetDropEvent dtde) {
	}




}
